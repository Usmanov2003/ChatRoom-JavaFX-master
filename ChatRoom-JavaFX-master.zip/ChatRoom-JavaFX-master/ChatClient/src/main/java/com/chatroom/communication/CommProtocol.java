package com.chatroom.communication;

/**
 *
 * @Title: CommProtocol.java
 * @Description: TODO 通信协议
 * @author ZhangJing https://github.com/Laity000/ChatRoom-JavaFX
 * @date 2017年6月15日 上午11:32:05
 *
 */
public enum CommProtocol {
	TEXT_PROTOCOL, WEBSOCKET_PROTOCOL
}
