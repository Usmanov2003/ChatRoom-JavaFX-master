package com.chatroom.messages;

//消息类型
public enum MessageType {
	CONNECT,DISCONNECT,MSG,QUERY,SUCCESS,FAIL,USERLIST,NOTIFICATION
}
