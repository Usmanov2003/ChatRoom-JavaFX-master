package com.chatroom.messages;

public class Utils {
	public static final String ALL = "★☆";
	public static final String SUCCESS = "success";
	public static final String FAIL = "fail";

}
